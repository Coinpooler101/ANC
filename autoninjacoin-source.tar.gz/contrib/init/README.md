Sample configuration files for:
```
SystemD: autoninjacoind.service
Upstart: autoninjacoind.conf
OpenRC:  autoninjacoind.openrc
         autoninjacoind.openrcconf
CentOS:  autoninjacoind.init
macOS:    org.autoninjacoin.autoninjacoind.plist
```
have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
