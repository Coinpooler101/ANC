
Debian
====================
This directory contains files used to package autoninjacoind/autoninjacoin-qt
for Debian-based Linux systems. If you compile autoninjacoind/autoninjacoin-qt yourself, there are some useful files here.

## autoninjacoin: URI support ##


autoninjacoin-qt.desktop  (Gnome / Open Desktop)
To install:

	sudo desktop-file-install autoninjacoin-qt.desktop
	sudo update-desktop-database

If you build yourself, you will either need to modify the paths in
the .desktop file or copy or symlink your autoninjacoin-qt binary to `/usr/bin`
and the `../../share/pixmaps/autoninjacoin128.png` to `/usr/share/pixmaps`

autoninjacoin-qt.protocol (KDE)

